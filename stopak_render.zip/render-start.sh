#!/usr/bin/env bash
set -e
cd backend
# run migrations if prisma available
if [ -f node_modules/.bin/prisma ]; then
  npx prisma migrate deploy || true
fi
# try to run built JS
if [ -f dist/index.js ]; then
  node dist/index.js
else
  node src/index.js
fi
