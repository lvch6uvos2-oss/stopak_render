const root = document.getElementById('root');
root.innerHTML = `<div style="padding:20px;font-family:Arial"><h1>СТОпак</h1><p>PWA frontend is running. API: <code>/api</code></p><p><a href="/api/jobs">/api/jobs (demo)</a></p></div>`;
if ('serviceWorker' in navigator) { navigator.serviceWorker.register('/sw.js').catch(()=>{}); }
