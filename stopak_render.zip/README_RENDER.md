# Stopak Render deploy
1. Push repository to GitHub as `stopak_render` on branch main.
2. In Render, create a new Web Service -> connect repository -> choose branch main.
3. Render will read render.yaml and create the service.
4. Set JWT_SECRET in Render dashboard (Environment -> New Variable).
5. Deploy and wait until service is live.
